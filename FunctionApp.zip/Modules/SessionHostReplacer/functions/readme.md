﻿# Functions

This is the folder where the functions go.

Depending on the complexity of the module, it is recommended to subdivide them into subfolders.

The module will pick up all .ps1 files recursively